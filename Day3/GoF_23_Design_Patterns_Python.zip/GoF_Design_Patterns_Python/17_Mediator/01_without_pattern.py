class Checkbox:
    def __init__(self): self.checked = False; self.email_field = None
    def toggle(self):
        self.checked = not self.checked
        if self.email_field:
            self.email_field.enabled = self.checked

class EmailField:
    def __init__(self): self.enabled = False

if __name__ == "__main__":
    checkbox = Checkbox(); email = EmailField()
    checkbox.email_field = email  # direct knowledge of peer
    checkbox.toggle()
    print(email.enabled)
