class Mediator:
    def notify(self, sender, event):
        if sender is self.checkbox and event == "toggle":
            self.email.enabled = self.checkbox.checked

class Checkbox:
    def __init__(self, mediator): self.checked = False; self.mediator = mediator
    def toggle(self):
        self.checked = not self.checked
        self.mediator.notify(self, "toggle")

class EmailField:
    def __init__(self): self.enabled = False

if __name__ == "__main__":
    mediator = Mediator()
    mediator.email = EmailField()
    mediator.checkbox = Checkbox(mediator)
    mediator.checkbox.toggle()
    print(mediator.email.enabled)
