class LargeImage:
    def __init__(self, filename):
        self.filename = filename
        self._load()
    def _load(self): print(f"Loading {self.filename} from disk...")
    def display(self): print(f"Displaying {self.filename}")

if __name__ == "__main__":
    image = LargeImage("banner.tiff")  # loads immediately
    print("Screen initialized")
    image.display()
