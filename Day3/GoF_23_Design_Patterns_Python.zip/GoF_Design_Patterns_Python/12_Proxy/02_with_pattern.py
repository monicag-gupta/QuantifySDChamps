from abc import ABC, abstractmethod

class Image(ABC):
    @abstractmethod
    def display(self): ...

class RealImage(Image):
    def __init__(self, filename):
        self.filename = filename
        print(f"Loading {filename} from disk...")
    def display(self): print(f"Displaying {self.filename}")

class ImageProxy(Image):
    def __init__(self, filename):
        self.filename = filename
        self._real = None
    def display(self):
        if self._real is None:
            self._real = RealImage(self.filename)
        self._real.display()

if __name__ == "__main__":
    image = ImageProxy("banner.tiff")
    print("Screen initialized")  # no image load yet
    image.display()
