from abc import ABC, abstractmethod

class Renderer(ABC):
    @abstractmethod
    def render(self, title, body): ...

class EmailRenderer(Renderer):
    def render(self, title, body): return f"EMAIL: {title} | {body}"

class PDFRenderer(Renderer):
    def render(self, title, body): return f"PDF: {title} | {body}"

class Report(ABC):
    def __init__(self, renderer): self.renderer = renderer
    @abstractmethod
    def send(self): ...

class SalesReport(Report):
    def send(self): return self.renderer.render("Sales", "Revenue up 12%")

class AuditReport(Report):
    def send(self): return self.renderer.render("Audit", "3 findings")

if __name__ == "__main__":
    print(AuditReport(PDFRenderer()).send())
