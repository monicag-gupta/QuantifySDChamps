class SalesEmailReport:
    def send(self): return "Sales report -> email"

class SalesPDFReport:
    def send(self): return "Sales report -> PDF"

class AuditEmailReport:
    def send(self): return "Audit report -> email"

class AuditPDFReport:
    def send(self): return "Audit report -> PDF"

if __name__ == "__main__":
    print(AuditPDFReport().send())
