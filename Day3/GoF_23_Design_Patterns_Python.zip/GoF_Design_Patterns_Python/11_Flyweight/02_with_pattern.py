class TreeType:
    def __init__(self, species, color, texture):
        self.species = species
        self.color = color
        self.texture = texture

    def draw(self, x, y):
        return f"{self.species} at ({x},{y}) using {self.texture}"

class TreeTypeFactory:
    _types = {}

    @classmethod
    def get(cls, species, color, texture):
        key = (species, color, texture)
        if key not in cls._types:
            cls._types[key] = TreeType(*key)
        return cls._types[key]

class Tree:
    def __init__(self, x, y, tree_type):
        self.x, self.y, self.tree_type = x, y, tree_type
    def draw(self): return self.tree_type.draw(self.x, self.y)

if __name__ == "__main__":
    oak = TreeTypeFactory.get("Oak", "green", "oak.png")
    forest = [Tree(i, i * 2, oak) for i in range(3)]
    print([tree.draw() for tree in forest])
    print(len(TreeTypeFactory._types))
