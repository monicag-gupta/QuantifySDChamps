class Tree:
    def __init__(self, x, y, species, color, texture):
        self.x, self.y = x, y
        self.species = species
        self.color = color
        self.texture = texture

if __name__ == "__main__":
    forest = [Tree(i, i * 2, "Oak", "green", "oak.png") for i in range(3)]
    print([tree.__dict__ for tree in forest])
