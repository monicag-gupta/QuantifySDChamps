class Order:
    def __init__(self): self._observers = []; self.status = None
    def subscribe(self, observer): self._observers.append(observer)
    def unsubscribe(self, observer): self._observers.remove(observer)
    def set_status(self, status):
        self.status = status
        for observer in list(self._observers):
            observer.update(self)

class EmailObserver:
    def update(self, order): print(f"Email: {order.status}")

class AnalyticsObserver:
    def update(self, order): print(f"Analytics: {order.status}")

class InventoryObserver:
    def update(self, order): print(f"Inventory: {order.status}")

if __name__ == "__main__":
    order = Order()
    for observer in (EmailObserver(), AnalyticsObserver(), InventoryObserver()):
        order.subscribe(observer)
    order.set_status("shipped")
