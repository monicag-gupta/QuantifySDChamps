def send_email(status): print(f"Email: {status}")
def update_analytics(status): print(f"Analytics: {status}")
def sync_inventory(status): print(f"Inventory: {status}")

class Order:
    def set_status(self, status):
        self.status = status
        send_email(status)
        update_analytics(status)
        sync_inventory(status)

if __name__ == "__main__":
    Order().set_status("shipped")
