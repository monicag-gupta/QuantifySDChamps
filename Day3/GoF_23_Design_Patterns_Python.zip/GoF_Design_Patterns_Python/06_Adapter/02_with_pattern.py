from abc import ABC, abstractmethod

class PaymentProcessor(ABC):
    @abstractmethod
    def pay(self, amount_dollars): ...

class LegacyGateway:
    def make_payment(self, cents):
        return f"Charged {cents} cents"

class LegacyGatewayAdapter(PaymentProcessor):
    def __init__(self, gateway):
        self.gateway = gateway

    def pay(self, amount_dollars):
        return self.gateway.make_payment(int(round(amount_dollars * 100)))


def checkout(processor: PaymentProcessor, amount):
    return processor.pay(amount)

if __name__ == "__main__":
    print(checkout(LegacyGatewayAdapter(LegacyGateway()), 19.99))
