class LegacyGateway:
    def make_payment(self, cents):
        return f"Charged {cents} cents"


def checkout(gateway, amount_dollars):
    cents = int(amount_dollars * 100)
    return gateway.make_payment(cents)

if __name__ == "__main__":
    print(checkout(LegacyGateway(), 19.99))
