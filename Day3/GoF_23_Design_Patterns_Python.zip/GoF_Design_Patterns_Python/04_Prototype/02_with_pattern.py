from copy import deepcopy

class Campaign:
    def __init__(self, name, channels, settings, tags):
        self.name = name
        self.channels = channels
        self.settings = settings
        self.tags = tags

    def clone(self, **changes):
        cloned = deepcopy(self)
        for key, value in changes.items():
            setattr(cloned, key, value)
        return cloned

    def __repr__(self):
        return f"Campaign({self.name!r}, {self.settings!r})"

if __name__ == "__main__":
    prototype = Campaign(
        "Standard",
        ["email", "social"],
        {"tracking": True, "budget": 1000},
        ["standard"],
    )
    launch_a = prototype.clone(name="Launch A")
    launch_b = prototype.clone(name="Launch B")
    launch_b.settings["budget"] = 2000
    print(launch_a)
    print(launch_b)
