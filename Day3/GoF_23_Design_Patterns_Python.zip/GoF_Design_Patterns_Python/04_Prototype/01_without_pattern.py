def create_campaign(name):
    return {
        "name": name,
        "channels": ["email", "social"],
        "settings": {"tracking": True, "budget": 1000},
        "tags": ["standard"]
    }

if __name__ == "__main__":
    a = create_campaign("Launch A")
    b = create_campaign("Launch B")
    b["settings"]["budget"] = 2000
    print(a)
    print(b)
