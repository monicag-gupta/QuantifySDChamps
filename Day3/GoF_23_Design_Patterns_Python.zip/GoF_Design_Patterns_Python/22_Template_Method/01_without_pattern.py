def import_csv(data):
    print("Open source")
    rows = [line.split(",") for line in data.splitlines()]
    print("Validate", len(rows), "rows")
    print("Save", rows)

def import_json(data):
    import json
    print("Open source")
    rows = json.loads(data)
    print("Validate", len(rows), "rows")
    print("Save", rows)

if __name__ == "__main__":
    import_csv("A,10\nB,20")
