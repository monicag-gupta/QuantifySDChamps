from abc import ABC, abstractmethod
import json

class DataImporter(ABC):
    def run(self, data):
        self.open_source()
        rows = self.parse(data)
        self.validate(rows)
        self.save(rows)

    def open_source(self): print("Open source")
    @abstractmethod
    def parse(self, data): ...
    def validate(self, rows): print("Validate", len(rows), "rows")
    def save(self, rows): print("Save", rows)

class CSVImporter(DataImporter):
    def parse(self, data): return [line.split(",") for line in data.splitlines()]

class JSONImporter(DataImporter):
    def parse(self, data): return json.loads(data)

if __name__ == "__main__":
    CSVImporter().run("A,10\nB,20")
