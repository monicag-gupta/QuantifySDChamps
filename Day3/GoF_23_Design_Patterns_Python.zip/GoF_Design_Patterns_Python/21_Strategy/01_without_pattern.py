def shipping_cost(order_total, method):
    if method == "standard":
        return 5 if order_total < 50 else 0
    elif method == "express":
        return 15
    elif method == "pickup":
        return 0
    raise ValueError("Unknown shipping method")

if __name__ == "__main__":
    print(shipping_cost(40, "express"))
