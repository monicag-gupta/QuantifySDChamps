from abc import ABC, abstractmethod

class ShippingStrategy(ABC):
    @abstractmethod
    def cost(self, order_total): ...

class StandardShipping(ShippingStrategy):
    def cost(self, order_total): return 5 if order_total < 50 else 0

class ExpressShipping(ShippingStrategy):
    def cost(self, order_total): return 15

class Pickup(ShippingStrategy):
    def cost(self, order_total): return 0

class Checkout:
    def __init__(self, shipping): self.shipping = shipping
    def total_shipping(self, order_total): return self.shipping.cost(order_total)

if __name__ == "__main__":
    checkout = Checkout(ExpressShipping())
    print(checkout.total_shipping(40))
