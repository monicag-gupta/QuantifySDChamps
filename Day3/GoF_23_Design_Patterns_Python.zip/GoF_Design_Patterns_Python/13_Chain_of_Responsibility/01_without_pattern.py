def handle_ticket(ticket):
    if ticket["severity"] == "critical":
        return "Incident team"
    elif ticket["type"] == "billing":
        return "Billing team"
    elif ticket["type"] == "technical":
        return "Tech support"
    return "General queue"

if __name__ == "__main__":
    print(handle_ticket({"severity": "normal", "type": "billing"}))
