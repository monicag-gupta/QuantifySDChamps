class Handler:
    def __init__(self): self.next = None
    def set_next(self, handler):
        self.next = handler
        return handler
    def handle(self, ticket):
        return self.next.handle(ticket) if self.next else "General queue"

class CriticalHandler(Handler):
    def handle(self, ticket):
        if ticket["severity"] == "critical": return "Incident team"
        return super().handle(ticket)

class BillingHandler(Handler):
    def handle(self, ticket):
        if ticket["type"] == "billing": return "Billing team"
        return super().handle(ticket)

class TechnicalHandler(Handler):
    def handle(self, ticket):
        if ticket["type"] == "technical": return "Tech support"
        return super().handle(ticket)

if __name__ == "__main__":
    first = CriticalHandler()
    first.set_next(BillingHandler()).set_next(TechnicalHandler())
    print(first.handle({"severity": "normal", "type": "billing"}))
