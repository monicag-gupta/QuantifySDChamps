GoF Design Patterns - Python Learning Pack

Each pattern folder contains:
- 01_without_pattern.py : intentionally coupled/conditional/duplicated baseline
- 02_with_pattern.py    : refactored GoF pattern solution
- 03_pattern_notes.docx : concise learning notes

Families:

Creational:
  - 01_Abstract_Factory: Abstract Factory
  - 02_Builder: Builder
  - 03_Factory_Method: Factory Method
  - 04_Prototype: Prototype
  - 05_Singleton: Singleton

Structural:
  - 06_Adapter: Adapter
  - 07_Bridge: Bridge
  - 08_Composite: Composite
  - 09_Decorator: Decorator
  - 10_Facade: Facade
  - 11_Flyweight: Flyweight
  - 12_Proxy: Proxy

Behavioral:
  - 13_Chain_of_Responsibility: Chain of Responsibility
  - 14_Command: Command
  - 15_Interpreter: Interpreter
  - 16_Iterator: Iterator
  - 17_Mediator: Mediator
  - 18_Memento: Memento
  - 19_Observer: Observer
  - 20_State: State
  - 21_Strategy: Strategy
  - 22_Template_Method: Template Method
  - 23_Visitor: Visitor