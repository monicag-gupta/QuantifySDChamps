class Team:
    def __init__(self):
        self._members = {101: "Ana", 102: "Ben", 103: "Chen"}

    def __iter__(self):
        for employee_id in sorted(self._members):
            yield self._members[employee_id]

if __name__ == "__main__":
    team = Team()
    for member in team:
        print(member)
