class Team:
    def __init__(self):
        self.members = {101: "Ana", 102: "Ben", 103: "Chen"}

if __name__ == "__main__":
    team = Team()
    for employee_id in sorted(team.members.keys()):
        print(team.members[employee_id])  # client knows storage structure
