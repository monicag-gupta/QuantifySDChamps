from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def accept(self, visitor): ...

class Circle(Shape):
    def __init__(self, radius): self.radius = radius
    def accept(self, visitor): return visitor.visit_circle(self)

class Rectangle(Shape):
    def __init__(self, width, height): self.width, self.height = width, height
    def accept(self, visitor): return visitor.visit_rectangle(self)

class ShapeVisitor(ABC):
    @abstractmethod
    def visit_circle(self, circle): ...
    @abstractmethod
    def visit_rectangle(self, rectangle): ...

class JSONExportVisitor(ShapeVisitor):
    def visit_circle(self, circle): return {"type": "circle", "radius": circle.radius}
    def visit_rectangle(self, rectangle):
        return {"type": "rectangle", "width": rectangle.width, "height": rectangle.height}

class DescriptionVisitor(ShapeVisitor):
    def visit_circle(self, circle): return f"Circle r={circle.radius}"
    def visit_rectangle(self, rectangle): return f"Rectangle {rectangle.width}x{rectangle.height}"

if __name__ == "__main__":
    shape = Circle(3)
    print(shape.accept(JSONExportVisitor()))
    print(shape.accept(DescriptionVisitor()))
