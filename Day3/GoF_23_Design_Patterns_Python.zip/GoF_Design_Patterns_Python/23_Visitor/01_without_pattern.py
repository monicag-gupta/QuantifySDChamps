class Circle:
    def __init__(self, radius): self.radius = radius
    def export_json(self): return {"type": "circle", "radius": self.radius}
    def describe(self): return f"Circle r={self.radius}"

class Rectangle:
    def __init__(self, width, height): self.width, self.height = width, height
    def export_json(self): return {"type": "rectangle", "width": self.width, "height": self.height}
    def describe(self): return f"Rectangle {self.width}x{self.height}"

if __name__ == "__main__":
    print(Circle(3).export_json())
