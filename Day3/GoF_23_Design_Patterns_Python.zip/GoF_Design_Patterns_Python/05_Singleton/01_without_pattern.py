class Config:
    def __init__(self):
        self.values = {}

if __name__ == "__main__":
    service_a_config = Config()
    service_b_config = Config()
    service_a_config.values["region"] = "IN"
    print(service_b_config.values)  # different object, state is missing
