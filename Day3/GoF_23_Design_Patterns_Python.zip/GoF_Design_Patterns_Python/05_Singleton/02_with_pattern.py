class Config:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.values = {}
        return cls._instance

if __name__ == "__main__":
    service_a_config = Config()
    service_b_config = Config()
    service_a_config.values["region"] = "IN"
    print(service_b_config.values)  # {'region': 'IN'}
    print(service_a_config is service_b_config)  # True
