class LightButton:
    def render(self):
        return "Light button"

class DarkButton:
    def render(self):
        return "Dark button"

class LightCheckbox:
    def render(self):
        return "Light checkbox"

class DarkCheckbox:
    def render(self):
        return "Dark checkbox"


def build_screen(theme: str):
    if theme == "light":
        button = LightButton()
        checkbox = LightCheckbox()
    elif theme == "dark":
        button = DarkButton()
        checkbox = DarkCheckbox()
    else:
        raise ValueError("Unknown theme")
    return button.render(), checkbox.render()


if __name__ == "__main__":
    print(build_screen("dark"))
