from abc import ABC, abstractmethod

class Button(ABC):
    @abstractmethod
    def render(self): ...

class Checkbox(ABC):
    @abstractmethod
    def render(self): ...

class LightButton(Button):
    def render(self): return "Light button"

class DarkButton(Button):
    def render(self): return "Dark button"

class LightCheckbox(Checkbox):
    def render(self): return "Light checkbox"

class DarkCheckbox(Checkbox):
    def render(self): return "Dark checkbox"

class UIFactory(ABC):
    @abstractmethod
    def create_button(self) -> Button: ...
    @abstractmethod
    def create_checkbox(self) -> Checkbox: ...

class LightFactory(UIFactory):
    def create_button(self): return LightButton()
    def create_checkbox(self): return LightCheckbox()

class DarkFactory(UIFactory):
    def create_button(self): return DarkButton()
    def create_checkbox(self): return DarkCheckbox()


def build_screen(factory: UIFactory):
    button = factory.create_button()
    checkbox = factory.create_checkbox()
    return button.render(), checkbox.render()

if __name__ == "__main__":
    print(build_screen(DarkFactory()))
