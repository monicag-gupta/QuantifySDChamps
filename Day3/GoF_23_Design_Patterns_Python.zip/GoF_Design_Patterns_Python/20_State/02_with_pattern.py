from abc import ABC, abstractmethod

class DocumentState(ABC):
    @abstractmethod
    def publish(self, document): ...

class Draft(DocumentState):
    def publish(self, document):
        print("Cannot publish; send for review first")

class Review(DocumentState):
    def publish(self, document):
        document.state = Published()
        print("Published")

class Published(DocumentState):
    def publish(self, document): print("Already published")

class Document:
    def __init__(self): self.state = Draft()
    def publish(self): self.state.publish(self)
    def submit_for_review(self): self.state = Review()

if __name__ == "__main__":
    d = Document(); d.publish(); d.submit_for_review(); d.publish(); d.publish()
