class Document:
    def __init__(self): self.state = "draft"
    def publish(self):
        if self.state == "draft":
            print("Cannot publish; send for review first")
        elif self.state == "review":
            self.state = "published"; print("Published")
        elif self.state == "published":
            print("Already published")

if __name__ == "__main__":
    d = Document(); d.publish(); d.state = "review"; d.publish()
