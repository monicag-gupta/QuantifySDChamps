from abc import ABC, abstractmethod

class Light:
    def on(self): print("Light ON")
    def off(self): print("Light OFF")

class Command(ABC):
    @abstractmethod
    def execute(self): ...
    @abstractmethod
    def undo(self): ...

class LightOnCommand(Command):
    def __init__(self, light): self.light = light
    def execute(self): self.light.on()
    def undo(self): self.light.off()

class RemoteButton:
    def __init__(self, command): self.command = command
    def press(self): self.command.execute()
    def press_undo(self): self.command.undo()

if __name__ == "__main__":
    button = RemoteButton(LightOnCommand(Light()))
    button.press()
    button.press_undo()
