class Light:
    def on(self): print("Light ON")
    def off(self): print("Light OFF")

if __name__ == "__main__":
    light = Light()
    light.on()   # UI button directly knows receiver method
    light.off()
