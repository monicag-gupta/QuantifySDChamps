class Inventory:
    def reserve(self, sku): return f"reserved {sku}"
class Payment:
    def charge(self, amount): return f"charged {amount}"
class Shipping:
    def create_label(self, sku): return f"label for {sku}"
class Email:
    def send_confirmation(self): return "confirmation sent"

class OrderFacade:
    def __init__(self):
        self.inventory = Inventory()
        self.payment = Payment()
        self.shipping = Shipping()
        self.email = Email()

    def place_order(self, sku, amount):
        return [
            self.inventory.reserve(sku),
            self.payment.charge(amount),
            self.shipping.create_label(sku),
            self.email.send_confirmation(),
        ]

if __name__ == "__main__":
    for step in OrderFacade().place_order("A-10", 499):
        print(step)
