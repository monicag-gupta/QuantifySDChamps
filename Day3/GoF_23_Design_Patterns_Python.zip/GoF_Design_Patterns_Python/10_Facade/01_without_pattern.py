class Inventory:
    def reserve(self, sku): return f"reserved {sku}"
class Payment:
    def charge(self, amount): return f"charged {amount}"
class Shipping:
    def create_label(self, sku): return f"label for {sku}"
class Email:
    def send_confirmation(self): return "confirmation sent"

if __name__ == "__main__":
    print(Inventory().reserve("A-10"))
    print(Payment().charge(499))
    print(Shipping().create_label("A-10"))
    print(Email().send_confirmation())
