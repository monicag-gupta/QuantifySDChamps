class Report:
    def __init__(self, title, summary=None, chart=None, appendix=None, confidential=False):
        self.title = title
        self.summary = summary
        self.chart = chart
        self.appendix = appendix
        self.confidential = confidential

    def __repr__(self):
        return f"Report({self.__dict__})"


if __name__ == "__main__":
    report = Report("Q3 Review", "Strong growth", None, "Raw data", True)
    print(report)
