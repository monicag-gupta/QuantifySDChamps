class Report:
    def __init__(self):
        self.title = None
        self.summary = None
        self.chart = None
        self.appendix = None
        self.confidential = False

    def __repr__(self):
        return f"Report({self.__dict__})"

class ReportBuilder:
    def __init__(self):
        self._report = Report()

    def title(self, value):
        self._report.title = value
        return self

    def summary(self, value):
        self._report.summary = value
        return self

    def chart(self, value):
        self._report.chart = value
        return self

    def appendix(self, value):
        self._report.appendix = value
        return self

    def confidential(self, value=True):
        self._report.confidential = value
        return self

    def build(self):
        if not self._report.title:
            raise ValueError("A report needs a title")
        return self._report

if __name__ == "__main__":
    report = (ReportBuilder()
              .title("Q3 Review")
              .summary("Strong growth")
              .appendix("Raw data")
              .confidential()
              .build())
    print(report)
