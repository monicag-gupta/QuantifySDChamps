class Notifier:
    def send(self, message):
        print(f"SEND: {message}")

class LoggingEncryptedNotifier(Notifier):
    def send(self, message):
        print(f"LOG: {message}")
        encrypted = message[::-1]
        print(f"SEND ENCRYPTED: {encrypted}")

if __name__ == "__main__":
    LoggingEncryptedNotifier().send("System ready")
