from abc import ABC, abstractmethod

class Notifier(ABC):
    @abstractmethod
    def send(self, message): ...

class BasicNotifier(Notifier):
    def send(self, message):
        print(f"SEND: {message}")

class NotifierDecorator(Notifier):
    def __init__(self, wrapped): self.wrapped = wrapped

class LoggingDecorator(NotifierDecorator):
    def send(self, message):
        print(f"LOG: {message}")
        self.wrapped.send(message)

class EncryptionDecorator(NotifierDecorator):
    def send(self, message):
        self.wrapped.send(message[::-1])

if __name__ == "__main__":
    notifier = LoggingDecorator(EncryptionDecorator(BasicNotifier()))
    notifier.send("System ready")
