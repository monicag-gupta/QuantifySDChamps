class Editor:
    def __init__(self): self.text = ""

if __name__ == "__main__":
    editor = Editor()
    history = []
    history.append(editor.text)  # history knows internal representation
    editor.text = "Version 1"
    history.append(editor.text)
    editor.text = "Version 2"
    editor.text = history[-1]
    print(editor.text)
