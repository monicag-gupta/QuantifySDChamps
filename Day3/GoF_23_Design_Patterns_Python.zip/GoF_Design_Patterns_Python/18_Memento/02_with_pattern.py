from dataclasses import dataclass

@dataclass(frozen=True)
class EditorMemento:
    text: str

class Editor:
    def __init__(self): self._text = ""
    def type(self, value): self._text += value
    def save(self): return EditorMemento(self._text)
    def restore(self, memento): self._text = memento.text
    def show(self): return self._text

class History:
    def __init__(self): self._items = []
    def push(self, memento): self._items.append(memento)
    def pop(self): return self._items.pop()

if __name__ == "__main__":
    editor, history = Editor(), History()
    editor.type("Version 1")
    history.push(editor.save())
    editor.type(" + Version 2")
    editor.restore(history.pop())
    print(editor.show())
