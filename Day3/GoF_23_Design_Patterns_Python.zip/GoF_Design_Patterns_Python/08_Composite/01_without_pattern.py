def total_cost(item):
    if item["type"] == "task":
        return item["cost"]
    if item["type"] == "package":
        return sum(total_cost(child) for child in item["children"])
    raise ValueError("Unknown item")

if __name__ == "__main__":
    project = {"type": "package", "children": [
        {"type": "task", "cost": 100},
        {"type": "package", "children": [
            {"type": "task", "cost": 50},
            {"type": "task", "cost": 75},
        ]},
    ]}
    print(total_cost(project))
