from abc import ABC, abstractmethod

class WorkItem(ABC):
    @abstractmethod
    def cost(self): ...

class Task(WorkItem):
    def __init__(self, amount): self.amount = amount
    def cost(self): return self.amount

class WorkPackage(WorkItem):
    def __init__(self, *children): self.children = list(children)
    def add(self, child): self.children.append(child)
    def cost(self): return sum(child.cost() for child in self.children)

if __name__ == "__main__":
    project = WorkPackage(
        Task(100),
        WorkPackage(Task(50), Task(75)),
    )
    print(project.cost())
