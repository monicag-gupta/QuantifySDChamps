from abc import ABC, abstractmethod

class Transport(ABC):
    @abstractmethod
    def deliver(self): ...

class Truck(Transport):
    def deliver(self): return "Delivered by road"

class Ship(Transport):
    def deliver(self): return "Delivered by sea"

class Logistics(ABC):
    @abstractmethod
    def create_transport(self) -> Transport: ...

    def plan_delivery(self):
        transport = self.create_transport()
        return f"Plan created. {transport.deliver()}"

class RoadLogistics(Logistics):
    def create_transport(self): return Truck()

class SeaLogistics(Logistics):
    def create_transport(self): return Ship()

if __name__ == "__main__":
    print(SeaLogistics().plan_delivery())
