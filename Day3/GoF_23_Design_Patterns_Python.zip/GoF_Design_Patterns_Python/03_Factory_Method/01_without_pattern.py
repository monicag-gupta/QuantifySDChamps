class Truck:
    def deliver(self): return "Delivered by road"

class Ship:
    def deliver(self): return "Delivered by sea"


def plan_delivery(mode):
    if mode == "road":
        transport = Truck()
    elif mode == "sea":
        transport = Ship()
    else:
        raise ValueError("Unsupported mode")
    return f"Plan created. {transport.deliver()}"

if __name__ == "__main__":
    print(plan_delivery("sea"))
