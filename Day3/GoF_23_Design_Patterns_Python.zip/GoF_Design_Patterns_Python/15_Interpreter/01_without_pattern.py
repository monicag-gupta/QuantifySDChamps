def can_access(user, expression):
    # brittle, hard-coded mini-language
    if expression == "admin OR manager":
        return user["role"] in ("admin", "manager")
    if expression == "manager AND active":
        return user["role"] == "manager" and user["active"]
    raise ValueError("Unsupported expression")

if __name__ == "__main__":
    user = {"role": "manager", "active": True}
    print(can_access(user, "manager AND active"))
