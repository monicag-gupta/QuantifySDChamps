from abc import ABC, abstractmethod

class Expression(ABC):
    @abstractmethod
    def interpret(self, context): ...

class Role(Expression):
    def __init__(self, name): self.name = name
    def interpret(self, context): return context["role"] == self.name

class IsActive(Expression):
    def interpret(self, context): return context["active"]

class And(Expression):
    def __init__(self, left, right): self.left, self.right = left, right
    def interpret(self, context):
        return self.left.interpret(context) and self.right.interpret(context)

class Or(Expression):
    def __init__(self, left, right): self.left, self.right = left, right
    def interpret(self, context):
        return self.left.interpret(context) or self.right.interpret(context)

if __name__ == "__main__":
    user = {"role": "manager", "active": True}
    rule = And(Role("manager"), IsActive())
    print(rule.interpret(user))
