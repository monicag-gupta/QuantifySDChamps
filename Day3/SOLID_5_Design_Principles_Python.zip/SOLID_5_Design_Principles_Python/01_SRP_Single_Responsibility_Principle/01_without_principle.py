from pathlib import Path


class SalesReport:
    def __init__(self, sales):
        self.sales = sales

    def total_sales(self):
        return sum(self.sales)

    def format_report(self):
        return f"Total sales: ${self.total_sales():,.2f}"

    def save(self, filename):
        Path(filename).write_text(self.format_report(), encoding="utf-8")


if __name__ == "__main__":
    report = SalesReport([1250.0, 980.5, 1420.25])
    report.save("sales_report.txt")
    print(report.format_report())
