from pathlib import Path


class SalesReportCalculator:
    def __init__(self, sales):
        self.sales = sales

    def total_sales(self):
        return sum(self.sales)


class ReportFormatter:
    def format_total(self, total):
        return f"Total sales: ${total:,.2f}"


class FileSaver:
    def save(self, filename, content):
        Path(filename).write_text(content, encoding="utf-8")


if __name__ == "__main__":
    calculator = SalesReportCalculator([1250.0, 980.5, 1420.25])
    formatter = ReportFormatter()
    saver = FileSaver()

    report_text = formatter.format_total(calculator.total_sales())
    saver.save("sales_report.txt", report_text)
    print(report_text)
