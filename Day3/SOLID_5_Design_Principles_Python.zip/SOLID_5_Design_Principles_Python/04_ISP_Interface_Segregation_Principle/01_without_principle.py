from abc import ABC, abstractmethod


class MultiFunctionMachine(ABC):
    @abstractmethod
    def print_document(self, document):
        raise NotImplementedError

    @abstractmethod
    def scan_document(self, document):
        raise NotImplementedError

    @abstractmethod
    def fax_document(self, document):
        raise NotImplementedError


class SimplePrinter(MultiFunctionMachine):
    def print_document(self, document):
        print("Printing:", document)

    def scan_document(self, document):
        raise NotImplementedError("This printer cannot scan")

    def fax_document(self, document):
        raise NotImplementedError("This printer cannot fax")


if __name__ == "__main__":
    printer = SimplePrinter()
    printer.print_document("Quarterly Report")
