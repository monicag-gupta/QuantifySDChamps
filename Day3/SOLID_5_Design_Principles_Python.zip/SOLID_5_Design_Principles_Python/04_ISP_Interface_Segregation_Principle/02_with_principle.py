from abc import ABC, abstractmethod


class Printer(ABC):
    @abstractmethod
    def print_document(self, document):
        raise NotImplementedError


class Scanner(ABC):
    @abstractmethod
    def scan_document(self, document):
        raise NotImplementedError


class Fax(ABC):
    @abstractmethod
    def fax_document(self, document):
        raise NotImplementedError


class SimplePrinter(Printer):
    def print_document(self, document):
        print("Printing:", document)


class OfficeMachine(Printer, Scanner, Fax):
    def print_document(self, document):
        print("Printing:", document)

    def scan_document(self, document):
        print("Scanning:", document)

    def fax_document(self, document):
        print("Faxing:", document)


if __name__ == "__main__":
    printer = SimplePrinter()
    printer.print_document("Quarterly Report")

    office_machine = OfficeMachine()
    office_machine.scan_document("Signed Contract")
