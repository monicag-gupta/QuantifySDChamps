def calculate_discount(customer_type, total):
    if customer_type == "regular":
        return total * 0.05
    elif customer_type == "premium":
        return total * 0.10
    elif customer_type == "vip":
        return total * 0.20
    else:
        return 0.0


if __name__ == "__main__":
    order_total = 1000.0
    for customer_type in ["regular", "premium", "vip"]:
        discount = calculate_discount(customer_type, order_total)
        print(customer_type, "discount =", discount)
