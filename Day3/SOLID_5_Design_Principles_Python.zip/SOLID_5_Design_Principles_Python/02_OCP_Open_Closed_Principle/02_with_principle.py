from abc import ABC, abstractmethod


class DiscountPolicy(ABC):
    @abstractmethod
    def discount(self, total):
        raise NotImplementedError


class RegularDiscount(DiscountPolicy):
    def discount(self, total):
        return total * 0.05


class PremiumDiscount(DiscountPolicy):
    def discount(self, total):
        return total * 0.10


class VipDiscount(DiscountPolicy):
    def discount(self, total):
        return total * 0.20


class Checkout:
    def __init__(self, discount_policy):
        self.discount_policy = discount_policy

    def final_price(self, total):
        return total - self.discount_policy.discount(total)


if __name__ == "__main__":
    order_total = 1000.0
    for policy in [RegularDiscount(), PremiumDiscount(), VipDiscount()]:
        checkout = Checkout(policy)
        print(type(policy).__name__, "final price =", checkout.final_price(order_total))
