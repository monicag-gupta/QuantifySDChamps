class Bird:
    def fly(self):
        return "Flying"


class Sparrow(Bird):
    pass


class Penguin(Bird):
    def fly(self):
        raise RuntimeError("Penguins cannot fly")


def make_bird_fly(bird):
    print(bird.fly())


if __name__ == "__main__":
    make_bird_fly(Sparrow())
    try:
        make_bird_fly(Penguin())
    except RuntimeError as exc:
        print("LSP problem:", exc)
