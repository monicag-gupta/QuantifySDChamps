from abc import ABC, abstractmethod


class Bird(ABC):
    @abstractmethod
    def move(self):
        raise NotImplementedError


class FlyingBird(Bird):
    @abstractmethod
    def fly(self):
        raise NotImplementedError


class Sparrow(FlyingBird):
    def move(self):
        return self.fly()

    def fly(self):
        return "Sparrow is flying"


class Penguin(Bird):
    def move(self):
        return "Penguin is swimming"


def make_flying_bird_fly(bird: FlyingBird):
    print(bird.fly())


if __name__ == "__main__":
    sparrow = Sparrow()
    penguin = Penguin()
    make_flying_bird_fly(sparrow)
    print(penguin.move())
