class EmailSender:
    def send(self, recipient, message):
        print(f"Email to {recipient}: {message}")


class NotificationService:
    def __init__(self):
        self.sender = EmailSender()  # concrete dependency

    def notify(self, recipient, message):
        self.sender.send(recipient, message)


if __name__ == "__main__":
    service = NotificationService()
    service.notify("learner@example.com", "Your class starts tomorrow.")
