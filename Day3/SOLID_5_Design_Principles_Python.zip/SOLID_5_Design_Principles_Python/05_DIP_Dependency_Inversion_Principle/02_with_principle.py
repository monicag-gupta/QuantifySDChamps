from abc import ABC, abstractmethod


class MessageSender(ABC):
    @abstractmethod
    def send(self, recipient, message):
        raise NotImplementedError


class EmailSender(MessageSender):
    def send(self, recipient, message):
        print(f"Email to {recipient}: {message}")


class SmsSender(MessageSender):
    def send(self, recipient, message):
        print(f"SMS to {recipient}: {message}")


class NotificationService:
    def __init__(self, sender: MessageSender):
        self.sender = sender

    def notify(self, recipient, message):
        self.sender.send(recipient, message)


if __name__ == "__main__":
    email_service = NotificationService(EmailSender())
    email_service.notify("learner@example.com", "Your class starts tomorrow.")

    sms_service = NotificationService(SmsSender())
    sms_service.notify("+10000000000", "Your class starts tomorrow.")
