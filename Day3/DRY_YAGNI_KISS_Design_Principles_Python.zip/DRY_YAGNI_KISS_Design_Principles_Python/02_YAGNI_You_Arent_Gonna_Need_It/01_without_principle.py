
"""Example that violates YAGNI (You Aren't Gonna Need It).

The current requirement is only to export a report as CSV, but the design adds
unused PDF, XML, cloud-sync, encryption, and scheduling options "for the future".
"""


class ReportExporter:
    def export_csv(self, rows: list[dict]) -> str:
        headers = rows[0].keys()
        lines = [",".join(headers)]
        for row in rows:
            lines.append(",".join(str(row[h]) for h in headers))
        return "\n".join(lines)

    def export_pdf(self, rows: list[dict]) -> bytes:
        # Not required by today's use case
        return b"PDF_PLACEHOLDER"

    def export_xml(self, rows: list[dict]) -> str:
        # Not required by today's use case
        return "<report />"

    def encrypt_export(self, content: str, key: str) -> str:
        # Speculative feature
        return f"encrypted({content})"

    def sync_to_cloud(self, content: str, provider: str) -> None:
        # Speculative feature
        print(f"Syncing to {provider}: {len(content)} characters")

    def schedule_export(self, cron_expression: str) -> None:
        # Speculative feature
        print(f"Scheduled with {cron_expression}")


if __name__ == "__main__":
    rows = [
        {"name": "Asha", "score": 91},
        {"name": "Ravi", "score": 84},
    ]
    exporter = ReportExporter()
    print(exporter.export_csv(rows))
