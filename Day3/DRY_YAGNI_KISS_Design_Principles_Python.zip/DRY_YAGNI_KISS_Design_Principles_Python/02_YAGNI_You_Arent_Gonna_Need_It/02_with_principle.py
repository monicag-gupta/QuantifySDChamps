
"""Example refactored to follow YAGNI (You Aren't Gonna Need It).

The implementation contains only the capability required today: CSV export.
New formats can be added when a real requirement appears.
"""


class CsvReportExporter:
    def export(self, rows: list[dict]) -> str:
        if not rows:
            return ""

        headers = list(rows[0].keys())
        lines = [",".join(headers)]
        for row in rows:
            lines.append(",".join(str(row[h]) for h in headers))
        return "\n".join(lines)


if __name__ == "__main__":
    rows = [
        {"name": "Asha", "score": 91},
        {"name": "Ravi", "score": 84},
    ]
    exporter = CsvReportExporter()
    print(exporter.export(rows))
