
"""Example that violates DRY (Don't Repeat Yourself).

The discount formula and receipt formatting are duplicated in multiple methods.
If the business rule changes, several places must be edited consistently.
"""


class OrderService:
    def checkout_online(self, customer_name: str, amount: float) -> str:
        # Duplicated discount rule
        if amount >= 1000:
            discount = amount * 0.10
        else:
            discount = amount * 0.05

        final_amount = amount - discount

        # Duplicated receipt formatting
        receipt = (
            f"Customer: {customer_name}\n"
            f"Original amount: ${amount:.2f}\n"
            f"Discount: ${discount:.2f}\n"
            f"Final amount: ${final_amount:.2f}"
        )
        return receipt

    def checkout_in_store(self, customer_name: str, amount: float) -> str:
        # Same discount rule repeated again
        if amount >= 1000:
            discount = amount * 0.10
        else:
            discount = amount * 0.05

        final_amount = amount - discount

        # Same receipt formatting repeated again
        receipt = (
            f"Customer: {customer_name}\n"
            f"Original amount: ${amount:.2f}\n"
            f"Discount: ${discount:.2f}\n"
            f"Final amount: ${final_amount:.2f}"
        )
        return receipt


if __name__ == "__main__":
    service = OrderService()
    print("ONLINE ORDER")
    print(service.checkout_online("Asha", 1200))
    print("\nIN-STORE ORDER")
    print(service.checkout_in_store("Ravi", 800))
