
"""Example refactored to follow DRY (Don't Repeat Yourself).

Shared business rules live in one place, so a future change is made once.
"""


def calculate_discount(amount: float) -> float:
    """Return the discount according to the single business rule."""
    rate = 0.10 if amount >= 1000 else 0.05
    return amount * rate


def format_receipt(customer_name: str, amount: float, discount: float) -> str:
    """Create a receipt using one reusable formatting function."""
    final_amount = amount - discount
    return (
        f"Customer: {customer_name}\n"
        f"Original amount: ${amount:.2f}\n"
        f"Discount: ${discount:.2f}\n"
        f"Final amount: ${final_amount:.2f}"
    )


class OrderService:
    def checkout(self, channel: str, customer_name: str, amount: float) -> str:
        discount = calculate_discount(amount)
        receipt = format_receipt(customer_name, amount, discount)
        return f"Channel: {channel}\n{receipt}"


if __name__ == "__main__":
    service = OrderService()
    print(service.checkout("Online", "Asha", 1200))
    print()
    print(service.checkout("In-store", "Ravi", 800))
