DRY, YAGNI, KISS Design Principles - Python Learning Pack

Each folder contains:
  01_without_principle.py  - example that violates the principle
  02_with_principle.py     - refactored solution
  03_principle_notes.docx  - study notes and before/after explanation

Principles:
  1. DRY - Don't Repeat Yourself
  2. YAGNI - You Aren't Gonna Need It
  3. KISS - Keep It Simple, Stupid
