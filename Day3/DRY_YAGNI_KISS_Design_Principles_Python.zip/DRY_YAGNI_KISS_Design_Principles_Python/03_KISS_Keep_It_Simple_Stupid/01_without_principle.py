
"""Example that violates KISS (Keep It Simple, Stupid).

A straightforward shipping-fee calculation is implemented through unnecessary
layers, dynamic dispatch, and configuration objects.
"""


class ShippingRuleRegistry:
    def __init__(self):
        self._rules = {}

    def register(self, name, rule):
        self._rules[name] = rule

    def resolve(self, name):
        return self._rules[name]


class ShippingContext:
    def __init__(self, registry, strategy_name, config):
        self.registry = registry
        self.strategy_name = strategy_name
        self.config = config

    def execute(self, order_total):
        rule = self.registry.resolve(self.strategy_name)
        return rule(order_total, self.config)


def tiered_shipping_rule(order_total, config):
    for threshold, fee in sorted(config["tiers"], reverse=True):
        if order_total >= threshold:
            return fee
    return config["default_fee"]


if __name__ == "__main__":
    registry = ShippingRuleRegistry()
    registry.register("tiered", tiered_shipping_rule)

    config = {
        "tiers": [(100, 0), (50, 5)],
        "default_fee": 10,
    }

    context = ShippingContext(registry, "tiered", config)
    for total in (35, 75, 150):
        print(f"Order ${total}: shipping ${context.execute(total)}")
