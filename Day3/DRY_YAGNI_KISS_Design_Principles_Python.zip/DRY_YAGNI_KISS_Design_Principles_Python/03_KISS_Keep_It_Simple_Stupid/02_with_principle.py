
"""Example refactored to follow KISS (Keep It Simple, Stupid).

The shipping rule is simple and stable, so a direct function is easier to read,
test, and maintain than a registry/strategy/configuration framework.
"""


def calculate_shipping(order_total: float) -> float:
    if order_total >= 100:
        return 0.0
    if order_total >= 50:
        return 5.0
    return 10.0


if __name__ == "__main__":
    for total in (35, 75, 150):
        fee = calculate_shipping(total)
        print(f"Order ${total}: shipping ${fee}")
