DISCOUNTS = {"regular":0,"silver":5,"gold":10}
def lookup_discount(customer_type): return DISCOUNTS.get(customer_type, 0)
if __name__ == "__main__": print("Discount:", lookup_discount("gold"))
