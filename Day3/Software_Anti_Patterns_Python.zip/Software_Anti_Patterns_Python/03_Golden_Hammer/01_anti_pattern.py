import json

class JsonEngine:
    def lookup_discount(self, customer_type):
        payload = json.dumps({"regular":0,"silver":5,"gold":10})
        return json.loads(payload).get(customer_type, 0)

if __name__ == "__main__": print("Discount:", JsonEngine().lookup_discount("gold"))
