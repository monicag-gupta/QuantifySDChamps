class PaymentGateway:
    def charge(self,amount): print(f"Charged {amount:.2f}")
class CheckoutService:
    def __init__(self,gateway): self.gateway=gateway
    def checkout(self,amount): self.gateway.charge(amount)
if __name__ == "__main__": CheckoutService(PaymentGateway()).checkout(250)
