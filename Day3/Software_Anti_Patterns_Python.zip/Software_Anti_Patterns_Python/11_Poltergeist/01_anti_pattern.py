class PaymentGateway:
    def charge(self,amount): print(f"Charged {amount:.2f}")
class PaymentCoordinator:
    def __init__(self,gateway): self.gateway=gateway
    def do_payment(self,amount): self.gateway.charge(amount)
class CheckoutService:
    def __init__(self): self.coordinator=PaymentCoordinator(PaymentGateway())
    def checkout(self,amount): self.coordinator.do_payment(amount)
if __name__ == "__main__": CheckoutService().checkout(250)
