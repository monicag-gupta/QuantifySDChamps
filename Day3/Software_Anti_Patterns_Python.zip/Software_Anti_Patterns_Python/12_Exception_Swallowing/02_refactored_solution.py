def parse_quantity(value):
    try:
        quantity=int(value)
    except ValueError as exc:
        raise ValueError(f"Quantity must be an integer: {value!r}") from exc
    if quantity < 0: raise ValueError("Quantity cannot be negative")
    return quantity
if __name__ == "__main__":
    try: print("Quantity:",parse_quantity("ten"))
    except ValueError as exc: print("Validation error:",exc)
