def parse_quantity(value):
    try:
        return int(value)
    except Exception:
        return 0
if __name__ == "__main__": print("Quantity:",parse_quantity("ten"))
