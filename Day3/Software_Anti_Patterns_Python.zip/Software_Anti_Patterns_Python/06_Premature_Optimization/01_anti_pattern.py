class NameFormatter:
    def __init__(self): self._cache={}
    def format_name(self, first, last):
        key=(first,last)
        if key not in self._cache:
            self._cache[key]=(first.strip()+" "+last.strip()).title()
        return self._cache[key]
if __name__ == "__main__": print(NameFormatter().format_name("  ada","lovelace "))
