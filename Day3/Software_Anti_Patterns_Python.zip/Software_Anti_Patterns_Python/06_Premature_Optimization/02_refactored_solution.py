def format_name(first,last): return f"{first.strip()} {last.strip()}".title()
if __name__ == "__main__": print(format_name("  ada","lovelace "))
