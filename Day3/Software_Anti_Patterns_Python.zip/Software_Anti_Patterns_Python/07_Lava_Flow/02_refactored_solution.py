CURRENT_TAX_RATE=0.18
def calculate_price(amount): return amount + amount*CURRENT_TAX_RATE
if __name__ == "__main__": print(calculate_price(1000))
