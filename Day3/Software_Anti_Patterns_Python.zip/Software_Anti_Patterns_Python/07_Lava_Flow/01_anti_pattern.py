def calculate_price(amount, use_old_engine=False):
    # LEGACY: nobody knows why this remains. Do not delete!
    if use_old_engine:
        return amount + amount*0.12
    return amount + amount*0.18
if __name__ == "__main__": print(calculate_price(1000))
