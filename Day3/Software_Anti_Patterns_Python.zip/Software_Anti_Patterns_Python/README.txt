SOFTWARE ANTI-PATTERNS - PYTHON LEARNING PACK

Unlike GoF or SOLID, anti-patterns do not have one universally fixed canonical count. This pack uses 12 practical, commonly taught software anti-patterns.

Each folder contains:
1. 01_anti_pattern.py - intentionally demonstrates the anti-pattern
2. 02_refactored_solution.py - corrected/refactored design
3. 03_anti_pattern_notes.docx - trainer/study notes

Included: God Object, Spaghetti Code, Golden Hammer, Copy-Paste Programming, Magic Numbers and Strings, Premature Optimization, Lava Flow, Boat Anchor, Singleton Abuse, Tight Coupling, Poltergeist, Exception Swallowing.
