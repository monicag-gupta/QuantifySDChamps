class OrderManager:
    def __init__(self):
        self.orders = []

    def create_order(self, customer_email, items):
        if "@" not in customer_email:
            raise ValueError("Invalid email")
        total = sum(price * qty for _, price, qty in items)
        order = {"email": customer_email, "items": items, "total": total}
        self.orders.append(order)
        print(f"Saved order for {customer_email}")
        print(f"Email sent: order total = {total:.2f}")
        print(f"REPORT: {customer_email} | {len(items)} items | {total:.2f}")
        return order

if __name__ == "__main__":
    OrderManager().create_order("learner@example.com", [("Python Course",100.0,1),("Exam Voucher",50.0,1)])
