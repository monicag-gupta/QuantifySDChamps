class OrderValidator:
    def validate_email(self, email):
        if "@" not in email:
            raise ValueError("Invalid email")

class OrderRepository:
    def __init__(self): self.orders = []
    def save(self, order):
        self.orders.append(order)
        print(f"Saved order for {order['email']}")

class OrderNotifier:
    def send_confirmation(self, order):
        print(f"Email sent: order total = {order['total']:.2f}")

class OrderReport:
    def print_summary(self, order):
        print(f"REPORT: {order['email']} | {len(order['items'])} items | {order['total']:.2f}")

class OrderService:
    def __init__(self, validator, repository, notifier, report):
        self.validator, self.repository = validator, repository
        self.notifier, self.report = notifier, report
    def create_order(self, email, items):
        self.validator.validate_email(email)
        order = {"email": email, "items": items, "total": sum(p*q for _,p,q in items)}
        self.repository.save(order); self.notifier.send_confirmation(order); self.report.print_summary(order)
        return order

if __name__ == "__main__":
    OrderService(OrderValidator(),OrderRepository(),OrderNotifier(),OrderReport()).create_order("learner@example.com", [("Python Course",100.0,1),("Exam Voucher",50.0,1)])
