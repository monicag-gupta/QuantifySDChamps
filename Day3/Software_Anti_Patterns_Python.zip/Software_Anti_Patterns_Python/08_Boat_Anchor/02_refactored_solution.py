class RegistrationService:
    def register(self,email): print("Registered:",email)
if __name__ == "__main__": RegistrationService().register("learner@example.com")
