def process_registration(age, paid, country, coupon):
    result = ""
    if age >= 18:
        if paid:
            if country == "IN":
                fee = 100
                if coupon == "SAVE10": fee -= 10
                result = f"Approved. Fee={fee}"
            else:
                fee = 120
                if coupon == "SAVE10": fee -= 10
                result = f"Approved. Fee={fee}"
        else:
            result = "Rejected: payment pending"
    else:
        result = "Rejected: underage"
    print(result); return result

if __name__ == "__main__": process_registration(25, True, "IN", "SAVE10")
