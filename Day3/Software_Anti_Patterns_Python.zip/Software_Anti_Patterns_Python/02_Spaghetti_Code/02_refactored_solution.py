def base_fee(country): return 100 if country == "IN" else 120
def apply_coupon(fee, coupon): return fee - 10 if coupon == "SAVE10" else fee

def process_registration(age, paid, country, coupon):
    if age < 18: return "Rejected: underage"
    if not paid: return "Rejected: payment pending"
    return f"Approved. Fee={apply_coupon(base_fee(country), coupon)}"

if __name__ == "__main__": print(process_registration(25, True, "IN", "SAVE10"))
