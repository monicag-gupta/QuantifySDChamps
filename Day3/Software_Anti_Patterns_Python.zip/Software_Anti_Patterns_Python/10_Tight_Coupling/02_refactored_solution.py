from typing import Protocol
class MessageSender(Protocol):
    def send(self,address,message): ...
class SmtpEmailSender:
    def send(self,address,message): print(f"SMTP -> {address}: {message}")
class EnrollmentService:
    def __init__(self,sender:MessageSender): self.sender=sender
    def enroll(self,email): print("Enrollment created"); self.sender.send(email,"Welcome!")
if __name__ == "__main__": EnrollmentService(SmtpEmailSender()).enroll("learner@example.com")
