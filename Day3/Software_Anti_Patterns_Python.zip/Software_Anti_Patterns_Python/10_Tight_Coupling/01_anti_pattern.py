class SmtpEmailSender:
    def send(self,address,message): print(f"SMTP -> {address}: {message}")
class EnrollmentService:
    def enroll(self,email):
        sender=SmtpEmailSender(); print("Enrollment created"); sender.send(email,"Welcome!")
if __name__ == "__main__": EnrollmentService().enroll("learner@example.com")
