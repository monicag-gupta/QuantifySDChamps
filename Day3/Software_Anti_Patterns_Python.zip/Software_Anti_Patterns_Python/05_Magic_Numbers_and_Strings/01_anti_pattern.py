def calculate_subscription(price, days_active, status):
    if status == "ACTIVE" and days_active > 30:
        return price * 0.85
    return price
if __name__ == "__main__": print(calculate_subscription(1000,45,"ACTIVE"))
