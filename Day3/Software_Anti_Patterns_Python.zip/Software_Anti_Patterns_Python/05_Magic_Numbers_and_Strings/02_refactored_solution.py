from enum import Enum
LOYALTY_THRESHOLD_DAYS=30
LOYALTY_DISCOUNT_RATE=0.15
class AccountStatus(str,Enum): ACTIVE="ACTIVE"; INACTIVE="INACTIVE"
def calculate_subscription(price, days_active, status):
    if status == AccountStatus.ACTIVE and days_active > LOYALTY_THRESHOLD_DAYS:
        return price * (1-LOYALTY_DISCOUNT_RATE)
    return price
if __name__ == "__main__": print(calculate_subscription(1000,45,AccountStatus.ACTIVE))
