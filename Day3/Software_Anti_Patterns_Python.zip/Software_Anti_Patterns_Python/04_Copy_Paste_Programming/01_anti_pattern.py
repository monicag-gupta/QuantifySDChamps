def invoice_india(amount):
    tax=amount*0.18; total=amount+tax
    return f"India invoice: subtotal={amount:.2f}, tax={tax:.2f}, total={total:.2f}"

def invoice_uae(amount):
    tax=amount*0.05; total=amount+tax
    return f"UAE invoice: subtotal={amount:.2f}, tax={tax:.2f}, total={total:.2f}"

if __name__ == "__main__":
    print(invoice_india(1000)); print(invoice_uae(1000))
