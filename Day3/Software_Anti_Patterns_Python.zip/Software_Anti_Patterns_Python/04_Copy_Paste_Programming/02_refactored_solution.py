TAX_RATES={"India":0.18,"UAE":0.05}
def invoice(country, amount):
    tax=amount*TAX_RATES[country]; total=amount+tax
    return f"{country} invoice: subtotal={amount:.2f}, tax={tax:.2f}, total={total:.2f}"
if __name__ == "__main__":
    print(invoice("India",1000)); print(invoice("UAE",1000))
