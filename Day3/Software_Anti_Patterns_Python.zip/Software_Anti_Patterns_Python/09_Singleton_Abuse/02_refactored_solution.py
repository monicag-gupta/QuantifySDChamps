class AppConfig:
    def __init__(self,currency): self.currency=currency
class CheckoutService:
    def __init__(self,config): self.config=config
    def checkout(self,amount): return f"{self.config.currency} {amount:.2f}"
if __name__ == "__main__": print(CheckoutService(AppConfig("USD")).checkout(100))
