class AppConfig:
    _instance=None
    def __new__(cls):
        if cls._instance is None:
            cls._instance=super().__new__(cls); cls._instance.currency="USD"
        return cls._instance
def checkout(amount): return f"{AppConfig().currency} {amount:.2f}"
if __name__ == "__main__": print(checkout(100))
